# VIEW1ON / NOVA — iOS Build, Code Signing & TestFlight Guide

This guide packages the shared **React + TypeScript + Capacitor** project (`/web`) into a signed **iOS `.ipa`** for **TestFlight** and **App Store Connect**, either locally via **Xcode** or in the cloud via **GitHub Actions (`macos-latest`)**.

---

## Option A: Cloud iOS Build (Recommended for 4GB RAM MacBook)

No local Xcode installation or heavy Mac compilation is needed:

1. Ensure Apple Developer GitHub Secrets are configured (see `DEVELOPMENT_SYSTEM.md`):
   - `APPLE_TEAM_ID`
   - `APPLE_CERTIFICATE_BASE64`, `APPLE_CERTIFICATE_PASSWORD`
   - `APPLE_PROVISION_PROFILE_BASE64`
   - `APP_STORE_CONNECT_API_KEY_ID`, `APP_STORE_CONNECT_API_ISSUER_ID`, `APP_STORE_CONNECT_API_KEY_BASE64`
2. Open **GitHub → Actions → Cloud iOS IPA Archive & TestFlight Build → Run workflow**.
3. Toggle `upload_to_testflight` (`false` to inspect `.ipa` artifact first, `true` to submit to TestFlight).

---

## Option B: Local Xcode Build (macOS)

From repository root:

```bash
cd web
npm install
npm run build
npx cap add ios          # first time only
npx cap sync ios
cd ..
node scripts/configure-ios-plist.mjs
cd web
npm run cap:open:ios
```

### Required Xcode Settings Before Archiving
1. Select the **App** target → **Signing & Capabilities**:
   - **Bundle Identifier**: `com.view1on`
   - Select your **Apple Developer Team**
   - Enable **Push Notifications** and **Background Modes → Remote notifications** (if push is enabled).
2. Verify `Info.plist` entries (automatically patched by `scripts/configure-ios-plist.mjs`):
   - `NSCameraUsageDescription`
   - `NSPhotoLibraryUsageDescription`
   - `NSPhotoLibraryAddUsageDescription`
   - `NSMicrophoneUsageDescription`
   - `ITSAppUsesNonExemptEncryption = NO`
3. Select **Any iOS Device (arm64)** → **Product → Archive** → **Distribute App → TestFlight & App Store Connect**.
