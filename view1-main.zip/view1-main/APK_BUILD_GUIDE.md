# NOVA / VIEW1ON — React + TypeScript + Capacitor Android APK Build Guide

This guide packages the mobile-first React + TypeScript editor (`web/`) into an installable Android APK (`com.view1on`) backed by **Jetpack Media3 Transformer** hardware MP4 rendering.

---

## 1. Configure Firebase Web Environment

Copy `web/.env.example` to `web/.env` (or configure AI Studio Secrets):

```env
VITE_FIREBASE_API_KEY=your_web_api_key
VITE_FIREBASE_AUTH_DOMAIN=view1on.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=view1on
VITE_FIREBASE_STORAGE_BUCKET=view1on.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

---

## 2. Build Web Bundle & Initialize Capacitor Android Project

Run from the `/web` directory:

```bash
npm install
npm run build
npx cap add android
```

---

## 3. Install Native Media3 Video Editor Plugin (`NovaVideoEditorPlugin`)

Copy the provided native Capacitor plugin files into the generated `android/` project:

1. **Copy Kotlin Plugin & BridgeActivity**:
   - Copy `capacitor-plugins/android/com/view1on/plugins/NovaVideoEditorPlugin.kt`  
     to `android/app/src/main/java/com/view1on/plugins/NovaVideoEditorPlugin.kt`.
   - Replace `android/app/src/main/java/com/view1on/MainActivity.java`  
     with `capacitor-plugins/android/MainActivity.java` (registers `NovaVideoEditorPlugin`).

2. **Add Jetpack Media3 Dependencies**:
   - Append the dependencies from `capacitor-plugins/android/capacitor-media3.gradle` into `android/app/build.gradle`:
     - `androidx.media3:media3-transformer:1.6.1`
     - `androidx.media3:media3-effect:1.6.1`
     - `androidx.media3:media3-common:1.6.1`
     - `androidx.media3:media3-exoplayer:1.6.1`
   - Ensure Kotlin plugin support is enabled in `android/app/build.gradle` if `MainActivity` is Java and `NovaVideoEditorPlugin.kt` is Kotlin (`apply plugin: 'kotlin-android'`).

3. **Verify Android Permissions & FileProvider (`android/app/src/main/AndroidManifest.xml`)**:
   - Ensure the manifest declares:
     ```xml
     <uses-permission android:name="android.permission.CAMERA" />
     <uses-permission android:name="android.permission.INTERNET" />
     ```
   - Capacitor already configures `${applicationId}.fileprovider` in `AndroidManifest.xml` (`file_paths.xml` with `cache-path`), which `NovaVideoEditorPlugin.kt` uses for camera video recording without broad storage permissions.

---

## 4. Sync & Generate Installable APK

```bash
npm run cap:apk:debug
```

- **Debug APK Output**:  
  `web/android/app/build/outputs/apk/debug/app-debug.apk`
- **Release APK / Play Bundle (AAB)**:
  Run `npm run cap:open` to open Android Studio (`Build -> Generate Signed Bundle / APK`), or run `./gradlew assembleRelease bundleRelease` after configuring your release keystore.
