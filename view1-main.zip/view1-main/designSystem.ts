export const PremiumThemeTokens = {
  brand: {
    name: 'VIEW1ON',
    appId: 'com.view1on',
  },
  colors: {
    primaryPurple: '#7C3AED',
    primaryPurpleDeep: '#5B21B6',
    secondaryElectricBlue: '#2563EB',
    secondaryElectricCyan: '#38BDF8',
    backgroundBlack: '#05050A',
    elevatedSurface: '#0A0B14',
    glassSurface: 'rgba(16, 17, 30, 0.72)',
    glassBorder: 'rgba(139, 92, 246, 0.28)',
    textWhite: '#F8FAFC',
    textLightGray: '#A1A1AA',
  },
  radii: {
    sm: 10,
    md: 16,
    lg: 22,
    pill: 9999,
  },
  typography: {
    displayFont: "'Outfit', sans-serif",
    bodyFont: "'Plus Jakarta Sans', sans-serif",
    monoFont: "'JetBrains Mono', monospace",
  },
  breakpoints: {
    mobileMax: 767,
    tabletMin: 768,
    desktopMin: 1120,
  },
} as const;

export type NeonAccent = 'none' | 'purple' | 'blue';
