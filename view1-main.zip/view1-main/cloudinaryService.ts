import { httpsCallable } from 'firebase/functions';
import { getFirebaseServices } from './firebase';
import { toSafeMediaSrc } from './securityGuard';

export interface CloudinarySignaturePayload {
  cloudName: string;
  apiKey: string;
  timestamp: number;
  signature: string;
  folder: string;
  publicId: string;
  resourceType: 'video' | 'image';
  uploadIntentId: string;
  uploadUrl: string;
}

export interface CloudinaryWebUploadResult {
  originalVideoUrl: string;
  optimizedVideoUrl: string;
  hlsUrl?: string;
  thumbnailUrl: string;
  publicId: string;
  durationSeconds: number;
  width?: number;
  height?: number;
  uploadIntentId?: string;
  cloudName?: string;
}

export interface CloudinaryServerEditOptions {
  trimStartSec?: number;
  trimEndSec?: number;
  width: number;
  height: number;
  cropInset?: number;
  rotationDeg?: number;
  flipH?: boolean;
  flipV?: boolean;
  filterPreset?: string;
  brightness?: number;
  contrast?: number;
  saturation?: number;
  temperature?: number;
  hueDeg?: number;
  speed?: number;
  muteOriginal?: boolean;
  quality?: 'standard' | 'high' | 'ultra';
}

const PUBLIC_CLOUD_NAME = (import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || '').trim().toLowerCase();
const PUBLIC_UPLOAD_PRESET = (import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET || '').trim();
const CLOUD_NAME_REGEX = /^[a-z0-9_-]{2,64}$/;

export function isWebCloudinaryUnsignedConfigured(): boolean {
  return (
    CLOUD_NAME_REGEX.test(PUBLIC_CLOUD_NAME) &&
    Boolean(PUBLIC_UPLOAD_PRESET) &&
    PUBLIC_UPLOAD_PRESET !== 'YOUR_CLOUDINARY_UPLOAD_PRESET'
  );
}

export function deriveCloudinaryDeliveryUrls(
  cloudName: string,
  publicId: string,
  rawSecureUrl: string
): { originalVideoUrl: string; optimizedVideoUrl: string; hlsUrl: string; thumbnailUrl: string } {
  const cleanCloud = cloudName.trim().toLowerCase();
  const cleanPublicId = publicId.trim().replace(/^\/+|\/+$/g, '');

  if (CLOUD_NAME_REGEX.test(cleanCloud) && cleanPublicId) {
    const encoded = cleanPublicId
      .split('/')
      .filter(Boolean)
      .map((seg) => encodeURIComponent(seg))
      .join('/');
    return {
      originalVideoUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/${encoded}.mp4`,
      optimizedVideoUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/q_auto,f_auto,vc_h264/${encoded}.mp4`,
      hlsUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/sp_auto/${encoded}.m3u8`,
      thumbnailUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/so_1,f_jpg,q_auto/${encoded}.jpg`,
    };
  }

  const safeOrig = toSafeMediaSrc(rawSecureUrl) || '';
  const optimizedVideoUrl =
    safeOrig.includes('/video/upload/') && !safeOrig.includes('/q_auto')
      ? safeOrig.replace('/video/upload/', '/video/upload/q_auto,f_auto,vc_h264/')
      : safeOrig;
  const hlsUrl = safeOrig.includes('/video/upload/')
    ? safeOrig
        .replace('/video/upload/', '/video/upload/sp_auto/')
        .replace(/\.(mp4|mov|webm|mkv|3gp|m4v)(\?.*)?$/i, '.m3u8')
    : '';
  const thumbnailUrl = safeOrig.includes('/video/upload/')
    ? safeOrig
        .replace('/video/upload/', '/video/upload/so_1,f_jpg,q_auto/')
        .replace(/\.(mp4|mov|webm|mkv|3gp|m4v)(\?.*)?$/i, '.jpg')
    : '';

  return {
    originalVideoUrl: safeOrig,
    optimizedVideoUrl,
    hlsUrl,
    thumbnailUrl,
  };
}

export function buildCloudinaryEditedVideoUrls(
  cloudName: string,
  publicId: string,
  rawSecureUrl: string,
  edits: CloudinaryServerEditOptions
): { editedVideoUrl: string; optimizedVideoUrl: string; thumbnailUrl: string } {
  const baseDelivery = deriveCloudinaryDeliveryUrls(cloudName, publicId, rawSecureUrl);
  const cleanCloud = cloudName.trim().toLowerCase();
  const cleanPublicId = publicId.trim().replace(/^\/+|\/+$/g, '');

  const segments: string[] = [];
  const trimStart = Math.max(0, edits.trimStartSec ?? 0);
  const trimEnd = edits.trimEndSec ?? 0;
  const trimOps: string[] = [];
  if (trimStart > 0.05) trimOps.push(`so_${trimStart.toFixed(2)}`);
  if (trimEnd > trimStart + 0.1) trimOps.push(`eo_${trimEnd.toFixed(2)}`);
  if (trimOps.length > 0) segments.push(trimOps.join(','));

  const cropInset = Math.max(0, Math.min(0.35, edits.cropInset ?? 0));
  if (cropInset > 0.01) {
    const scale = Math.max(0.3, 1 - cropInset * 2);
    segments.push(`c_crop,w_${scale.toFixed(2)},h_${scale.toFixed(2)},g_center`);
  }

  const safeW = Math.max(240, Math.min(2160, Math.round(edits.width / 2) * 2));
  const safeH = Math.max(240, Math.min(2160, Math.round(edits.height / 2) * 2));
  segments.push(`c_fill,g_auto,w_${safeW},h_${safeH}`);

  const rotNorm = (((Math.round(edits.rotationDeg ?? 0) % 360) + 360) % 360);
  if (rotNorm !== 0) segments.push(`a_${rotNorm}`);
  if (edits.flipH) segments.push('a_hflip');
  if (edits.flipV) segments.push('a_vflip');

  const speed = edits.speed ?? 1;
  if (Math.abs(speed - 1) > 0.04) {
    const accelPct = Math.max(-50, Math.min(200, Math.round((speed - 1) * 100)));
    segments.push(`e_accelerate:${accelPct}`);
  }
  if (edits.muteOriginal) {
    segments.push('ac_none');
  }

  let brightAdj = Math.round((edits.brightness ?? 0) * 100);
  let contrastAdj = Math.round((edits.contrast ?? 0) * 100);
  let satAdj = Math.round((edits.saturation ?? 0) * 100);
  let hueAdj = Math.round(((edits.hueDeg ?? 0) / 180) * 100);
  let sepiaVal = 0;

  const temp = edits.temperature ?? 0;
  if (temp > 0.05) sepiaVal += Math.round(temp * 30);
  else if (temp < -0.05) hueAdj += Math.round(Math.abs(temp) * 20);

  switch (edits.filterPreset) {
    case 'noir_bw':
      segments.push('e_grayscale');
      contrastAdj += 25;
      break;
    case 'cinema_gold':
      sepiaVal += 15;
      contrastAdj += 18;
      break;
    case 'retro_vhs':
      sepiaVal += 24;
      satAdj -= 20;
      break;
    case 'warm_sunset':
      sepiaVal += 18;
      satAdj += 20;
      break;
    case 'cool_ice':
      hueAdj += 22;
      satAdj -= 12;
      break;
    case 'cyber_neon':
      contrastAdj += 20;
      satAdj += 35;
      hueAdj += 16;
      break;
    case 'vivid':
      contrastAdj += 16;
      satAdj += 40;
      break;
    case 'bright':
      brightAdj += 22;
      break;
    case 'contrast':
      contrastAdj += 36;
      break;
    default:
      break;
  }

  if (brightAdj !== 0) segments.push(`e_brightness:${Math.max(-99, Math.min(99, brightAdj))}`);
  if (contrastAdj !== 0) segments.push(`e_contrast:${Math.max(-99, Math.min(99, contrastAdj))}`);
  if (satAdj !== 0) segments.push(`e_saturation:${Math.max(-99, Math.min(99, satAdj))}`);
  if (hueAdj !== 0) segments.push(`e_hue:${Math.max(-99, Math.min(99, hueAdj))}`);
  if (sepiaVal > 0) segments.push(`e_sepia:${Math.min(100, sepiaVal)}`);

  const chain = segments.join('/');
  const qPreset = edits.quality === 'standard' ? 'q_auto:good' : 'q_auto:best';
  const thumbOffset = (trimStart + 0.5).toFixed(2);

  if (CLOUD_NAME_REGEX.test(cleanCloud) && cleanPublicId) {
    const encoded = cleanPublicId
      .split('/')
      .filter(Boolean)
      .map((seg) => encodeURIComponent(seg))
      .join('/');
    return {
      editedVideoUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/${chain}/${qPreset},f_mp4,vc_h264/${encoded}.mp4`,
      optimizedVideoUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/${chain}/q_auto,f_auto,vc_h264/${encoded}.mp4`,
      thumbnailUrl: `https://res.cloudinary.com/${cleanCloud}/video/upload/so_${thumbOffset},c_fill,g_auto,w_${safeW},h_${safeH},f_jpg,q_auto/${encoded}.jpg`,
    };
  }

  const safeOrig = baseDelivery.originalVideoUrl;
  if (safeOrig.includes('/video/upload/')) {
    return {
      editedVideoUrl: safeOrig.replace('/video/upload/', `/video/upload/${chain}/${qPreset},f_mp4,vc_h264/`),
      optimizedVideoUrl: safeOrig.replace('/video/upload/', `/video/upload/${chain}/q_auto,f_auto,vc_h264/`),
      thumbnailUrl: safeOrig
        .replace('/video/upload/', `/video/upload/so_${thumbOffset},c_fill,g_auto,w_${safeW},h_${safeH},f_jpg,q_auto/`)
        .replace(/\.(mp4|mov|webm|mkv|3gp|m4v)(\?.*)?$/i, '.jpg'),
    };
  }

  return {
    editedVideoUrl: baseDelivery.originalVideoUrl,
    optimizedVideoUrl: baseDelivery.optimizedVideoUrl,
    thumbnailUrl: baseDelivery.thumbnailUrl,
  };
}

async function requestSignedCloudinaryParams(
  resourceType: 'video' | 'image',
  mimeType: string,
  fileSizeBytes: number
): Promise<CloudinarySignaturePayload | null> {
  const services = getFirebaseServices();
  if (!services || !services.auth.currentUser) return null;
  try {
    const callable = httpsCallable<
      { resourceType: 'video' | 'image'; mimeType: string; fileSizeBytes: number; uploadIntentId: string },
      CloudinarySignaturePayload
    >(services.functions, 'generateCloudinaryUploadSignature');

    const intentId = `web_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    const res = await callable({
      resourceType,
      mimeType,
      fileSizeBytes,
      uploadIntentId: intentId,
    });
    if (res.data?.signature && res.data?.uploadUrl) {
      return res.data;
    }
    return null;
  } catch {
    return null;
  }
}

export async function uploadMediaToCloudinary(params: {
  file: Blob;
  fileName: string;
  mimeType: string;
  resourceType: 'video' | 'image';
  onProgress: (percent: number) => void;
  abortSignal?: AbortSignal;
}): Promise<CloudinaryWebUploadResult | null> {
  const signed = await requestSignedCloudinaryParams(params.resourceType, params.mimeType, params.file.size);

  if (!signed && !isWebCloudinaryUnsignedConfigured()) {
    return null; // Caller will fall back cleanly to Firebase Storage
  }

  const effectiveCloud = signed?.cloudName || PUBLIC_CLOUD_NAME;
  const uploadUrl =
    signed?.uploadUrl || `https://api.cloudinary.com/v1_1/${effectiveCloud}/${params.resourceType}/upload`;

  const formData = new FormData();
  formData.append('file', params.file, params.fileName);
  formData.append('resource_type', params.resourceType);

  if (signed) {
    formData.append('api_key', signed.apiKey);
    formData.append('timestamp', String(signed.timestamp));
    formData.append('signature', signed.signature);
    formData.append('folder', signed.folder);
    formData.append('public_id', signed.publicId);
  } else {
    formData.append('upload_preset', PUBLIC_UPLOAD_PRESET);
  }

  const rawJson = await new Promise<Record<string, unknown>>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    let settled = false;

    const finishErr = (err: Error) => {
      if (settled) return;
      settled = true;
      reject(err);
    };

    if (params.abortSignal) {
      if (params.abortSignal.aborted) {
        xhr.abort();
        finishErr(new Error('Upload cancelled.'));
        return;
      }
      params.abortSignal.addEventListener(
        'abort',
        () => {
          xhr.abort();
          finishErr(new Error('Upload cancelled by user.'));
        },
        { once: true }
      );
    }

    xhr.open('POST', uploadUrl, true);
    xhr.upload.onprogress = (evt) => {
      if (evt.lengthComputable && evt.total > 0) {
        params.onProgress(Math.min(99, Math.round((evt.loaded / evt.total) * 100)));
      }
    };
    xhr.onload = () => {
      if (settled) return;
      settled = true;
      try {
        const parsed = JSON.parse(xhr.responseText || '{}') as Record<string, unknown>;
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(parsed);
        } else {
          const msg =
            (parsed.error as { message?: string } | undefined)?.message ||
            `Cloudinary upload failed (${xhr.status})`;
          reject(new Error(msg));
        }
      } catch {
        reject(new Error(`Cloudinary response invalid (${xhr.status})`));
      }
    };
    xhr.onerror = () => finishErr(new Error('Network error during Cloudinary upload. Check internet connection and retry.'));
    xhr.onabort = () => finishErr(new Error('Upload cancelled by user.'));
    xhr.send(formData);
  });

  const secureUrl = toSafeMediaSrc(String(rawJson.secure_url || ''));
  const publicId = String(rawJson.public_id || signed?.publicId || '');
  const durationSeconds = Math.max(0, Math.round(Number(rawJson.duration || 0)));
  const videoWidth = Math.max(0, Math.round(Number(rawJson.width || 0)));
  const videoHeight = Math.max(0, Math.round(Number(rawJson.height || 0)));

  if (!secureUrl) {
    throw new Error('Cloudinary response did not contain a valid HTTPS URL.');
  }

  if (params.resourceType === 'image') {
    params.onProgress(100);
    return {
      originalVideoUrl: secureUrl,
      optimizedVideoUrl: secureUrl,
      thumbnailUrl: secureUrl,
      publicId,
      durationSeconds: 0,
      width: videoWidth || undefined,
      height: videoHeight || undefined,
      uploadIntentId: signed?.uploadIntentId,
      cloudName: effectiveCloud,
    };
  }

  const delivery = deriveCloudinaryDeliveryUrls(effectiveCloud, publicId, secureUrl);
  if (!delivery.originalVideoUrl || delivery.originalVideoUrl === delivery.thumbnailUrl) {
    throw new Error('Video delivery validation failed: resolved video URL cannot equal thumbnail URL.');
  }

  params.onProgress(100);
  console.info('[NOVA-Player] Cloudinary upload completed', {
    publicId,
    durationSeconds,
    signed: Boolean(signed),
  });

  return {
    originalVideoUrl: delivery.originalVideoUrl,
    optimizedVideoUrl: delivery.optimizedVideoUrl,
    hlsUrl: delivery.hlsUrl || undefined,
    thumbnailUrl: delivery.thumbnailUrl,
    publicId,
    durationSeconds,
    width: videoWidth || undefined,
    height: videoHeight || undefined,
    uploadIntentId: signed?.uploadIntentId,
    cloudName: effectiveCloud,
  };
}
