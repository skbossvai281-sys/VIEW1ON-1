import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { initializeAppCheck, ReCaptchaV3Provider, type AppCheck } from 'firebase/app-check';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, type Auth, type User } from 'firebase/auth';
import { doc, getDoc, getFirestore, serverTimestamp, setDoc, type Firestore } from 'firebase/firestore';
import { getStorage, type FirebaseStorage } from 'firebase/storage';
import { getFunctions, type Functions } from 'firebase/functions';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'view1on.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'view1on',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'view1on.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
};

const recaptchaSiteKey = import.meta.env.VITE_RECAPTCHA_V3_SITE_KEY || '';

export const isWebFirebaseConfigured = (): boolean =>
  Boolean(firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId);

let appInstance: FirebaseApp | null = null;
let appCheckInstance: AppCheck | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;
let storageInstance: FirebaseStorage | null = null;
let functionsInstance: Functions | null = null;

export function getFirebaseServices() {
  if (!isWebFirebaseConfigured()) {
    return null;
  }
  if (!appInstance) {
    appInstance = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
    if (recaptchaSiteKey && typeof window !== 'undefined') {
      appCheckInstance = initializeAppCheck(appInstance, {
        provider: new ReCaptchaV3Provider(recaptchaSiteKey),
        isTokenAutoRefreshEnabled: true,
      });
    }
    authInstance = getAuth(appInstance);
    dbInstance = getFirestore(appInstance);
    storageInstance = getStorage(appInstance);
    functionsInstance = getFunctions(appInstance);
  }
  return {
    app: appInstance!,
    appCheck: appCheckInstance,
    auth: authInstance!,
    db: dbInstance!,
    storage: storageInstance!,
    functions: functionsInstance!,
  };
}

/**
 * Ensures the signed-in user has a canonical `users/{uid}` Firestore record so
 * Watch Page likes, comments, subscriptions, bookmarks, and uploads comply with strict rules.
 */
export async function ensureWebUserProfile(user: User): Promise<void> {
  const services = getFirebaseServices();
  if (!services || !user || user.isAnonymous) return;
  try {
    const userRef = doc(services.db, 'users', user.uid);
    const snap = await getDoc(userRef);
    if (snap.exists()) return;
    const rawName = (user.displayName || user.email?.split('@')[0] || 'NOVA Creator').trim().slice(0, 60);
    const handleBase = rawName.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 24) || 'creator';
    await setDoc(userRef, {
      userId: user.uid,
      email: user.email || null,
      displayName: rawName || 'NOVA Creator',
      username: `@${handleBase}`,
      photoUrl: user.photoURL && user.photoURL.startsWith('https://') ? user.photoURL : null,
      role: 'user',
      accountStatus: 'active',
      recentSearches: [],
      savedVideoIds: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[NOVA-Auth] Unable to bootstrap user profile:', err instanceof Error ? err.message : String(err));
  }
}

export async function signInWithGoogleWeb() {
  const services = getFirebaseServices();
  if (!services) {
    throw new Error('Firebase Web SDK environment variables (VITE_FIREBASE_*) are not configured.');
  }
  const provider = new GoogleAuthProvider();
  const credential = await signInWithPopup(services.auth, provider);
  if (credential.user) {
    await ensureWebUserProfile(credential.user);
  }
  return credential;
}

export async function signOutWeb() {
  const services = getFirebaseServices();
  if (!services) return;
  await signOut(services.auth);
}
